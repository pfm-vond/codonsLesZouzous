﻿using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace $ext_safeprojectname$.$safeprojectname$
{
    public record Config();

    public class Program
    {
        static async Task Main(string[] args)
        {
            IConfiguration cfg = new ConfigurationBuilder()
                .AddCommandLine(args)
                .AddJsonFile("$ext_configfile$.json")
                .AddEnvironmentVariables()
                .Build();

            cfg.GetSection("Config").Get<Config>();
            
            await Task.CompletedTask;
        }
    }
}
