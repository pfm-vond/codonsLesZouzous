﻿using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace $ext_safeprojectname$.$safeprojectname$
{
    public class Program
    {
        public static void Main(string[] args)
        {
        }

        public static async Task Main(string[] args)
        {
            await Task.CompletedTask;
        }
    }
}
