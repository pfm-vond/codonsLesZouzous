﻿using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public record Config();

    public class Program
    {
        static async Task Main(string[] args)
        {
            IConfiguration cfg = new ConfigurationBuilder()
                .AddCommandLine(args)
                .AddJsonFile("appconfig.json")
                .AddEnvironmentVariables()
                .Build();

            cfg.GetSection("Config").Get<Config>();
            
            await Task.CompletedTask;
        }
    }
}
